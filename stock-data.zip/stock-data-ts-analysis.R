# Installing and including required libraries
# install.packages("forecast")
# install.packages("ggplot2")

library(dplyr)
library(forecast)
library(ggplot2)

# Loading Data
data <- read.csv('^NSEI.csv')
print(data)

# Description of the loaded data
summary(data)
str(data)
dim(data)

# Data Pre-processing
## Detecting any missing value
colSums(is.na(data))
data <- data %>% filter(!grepl("null", Date))
data <- data %>% filter(!grepl("null", Open))
data <- data %>% filter(!grepl("null", High))
data <- data %>% filter(!grepl("null", Low))
data <- data %>% filter(!grepl("null", Close))
data <- data %>% filter(!grepl("null", Adj.Close))
data <- data %>% filter(!grepl("null", Volume))

## Converting the data type of the column "Date" from string to date-time
data$Date <- as.POSIXct(data$Date)
str(data)
data <- data %>%
  mutate(
    Open = as.numeric(Open),
    High = as.numeric(High),
    Low = as.numeric(Low),
    Close = as.numeric(Close),
    Adj.Close = as.numeric(Adj.Close),
    Volume = as.numeric(Volume)
  )
str(data)
# Time-series analysis
## Creating a time series object
ts_data <- ts(data$Close, frequency = 1)
## Plotting the object over time
autoplot(ts_data) + labs(title = "Closing Prices of NSEI Index")

# Fitting the time-series object to an ARIMA model
arima_model <- auto.arima(ts_data)

# Predicting the time-series object for the next 12 months or 1 year
forecast_values <- forecast(arima_model, h = 12 * 30)
print(forecast_values)

# Plotting forecasted data and original values
plot(forecast_values, main = "Forecasted Closing Prices with 95% Prediction Intervals")

# Original time-series object defined explicitly with the closing prices
lines(ts_data, col = "blue")

# Chart legend
legend("topleft", legend = c("Original Data", "Forecast"), col = c("blue", "red"), lty = 1)

# Confidence intervals
shade <- forecast_values$mean - 1.96 * as.numeric(forecast_values$se)
shadu <- forecast_values$mean + 1.96 * as.numeric(forecast_values$se)
polygon(c(time(forecast_values$lower), rev(time(forecast_values$upper))), c(shade, rev(shadu)), col = "gray", border = NA, density = 25)

# Chart title
title(ylab = "Closing Prices", xlab = "Time")

is.na(forecast_values$se)

# Model performance evaluation
actual_values <- data$Close[1:length(forecast_values$mean)]
MAE <- mean(abs(forecast_values$mean - actual_values))
MSE <- mean((forecast_values$mean - actual_values)^2)
RMSE <- sqrt(mean((forecast_values$mean - actual_values)^2))
MAPE <- mean(abs((actual_values - forecast_values$mean) / actual_values)) * 100
Bias <- mean(forecast_values$mean - actual_values)

print(MAE)
print(MSE)
print(RMSE)
print(MAPE)
print(Bias)

evaluation_table <- data.frame(
  MAE = MAE,
  MSE = MSE,
  RMSE = RMSE,
  MAPE = MAPE,
  Bias = Bias
)

print(evaluation_table)

